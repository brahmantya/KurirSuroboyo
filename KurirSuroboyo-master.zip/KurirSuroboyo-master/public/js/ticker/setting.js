(function($) {
	'use strict';	
    $('.twitter-feed').list_ticker({
        speed:5000,
        effect:'fade'
    });	
})(jQuery);