<?php

namespace App\Controllers;

class Aboutus extends BaseController
{
    public function index()
    {
        return view('aboutuspage');
    }
}
