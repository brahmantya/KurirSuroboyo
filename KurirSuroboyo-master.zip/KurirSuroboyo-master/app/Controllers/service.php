<?php

namespace App\Controllers;

class Service extends BaseController
{
    public function index()
    {
        return view('servicepage');
    }
}
